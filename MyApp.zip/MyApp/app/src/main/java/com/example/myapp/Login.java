package com.example.myapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Login extends AppCompatActivity {
    EditText mail;
    EditText password;
    FirebaseAuth fauth;
    Button login;
    TextView link;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mail=(EditText)findViewById(R.id.txtEmail);
        password=(EditText)findViewById(R.id.txtPwd);
        link=(TextView) findViewById(R.id.Registerhere);

        login=(Button) findViewById(R.id.btnLogin);
        fauth=FirebaseAuth.getInstance();
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email=mail.getText().toString();
                String pass=password.getText().toString();
                if(TextUtils.isEmpty(email)){
                    mail.setError("Please enter email");
                    return;
                }
                if(TextUtils.isEmpty(pass)){
                    password.setError("Please enter password");
                    return;
                }
                if(pass.length()<6){
                    password.setError("Password length must be more than 6");
                }
                fauth.signInWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Login.this,"Login successfully",Toast.LENGTH_LONG).show();
                            startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        }else{
                            Toast.makeText(Login.this,"Please try again"+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                        }

                    }


                });
            }
        });
        link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Register.class));
            }
        });
    }
}