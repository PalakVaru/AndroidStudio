package com.example.myapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.nfc.Tag;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;


import java.util.HashMap;
import java.util.Map;

public class Register extends AppCompatActivity {
    public static final String TAG = "TAG";
    EditText name;
    EditText mail;
    EditText password;
    Button register;
    TextView link;
    FirebaseAuth fauth;
    FirebaseFirestore fstore;
    String userID;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name=(EditText)findViewById(R.id.txtName);
        mail=(EditText)findViewById(R.id.txtEmail);
        name=(EditText)findViewById(R.id.txtName);
        password=(EditText)findViewById(R.id.txtPwd);
        link=(TextView)findViewById(R.id.lnkLogin);
        register=(Button) findViewById(R.id.btnLogin);
        fauth=FirebaseAuth.getInstance();
        fstore=FirebaseFirestore.getInstance();
        if(fauth.getCurrentUser()!=null){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        }
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String email=mail.getText().toString();
                String pass=password.getText().toString();
                final String nam=name.getText().toString();
                if(TextUtils.isEmpty(email)){
                    mail.setError("Please enter email");
                    return;
                }
                if(TextUtils.isEmpty(pass)){
                    password.setError("Please enter password");
                    return;
                }
                 if(pass.length()<6){
                     password.setError("Password length must be more than 6");
                 }
                 fauth.createUserWithEmailAndPassword(email,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                     @Override
                     public void onComplete(@NonNull Task<AuthResult> task) {
                         if(task.isSuccessful()){
                             Toast.makeText(Register.this,"Register successfully",Toast.LENGTH_LONG).show();
                             userID=fauth.getCurrentUser().getUid();
                             DocumentReference documentReference=fstore.collection("user").document(userID);
                             Map<String,Object> user=new HashMap<>();
                             user.put("fname",nam);
                             user.put("email",email);
                             documentReference.set(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                                 @Override
                                 public void onSuccess(Void aVoid) {
                                     Log.d(TAG,"profile created"+userID);
                                 }
                             }).addOnFailureListener(new OnFailureListener() {
                                 @Override
                                 public void onFailure(@NonNull Exception e) {
                                     Log.d(TAG,"profile created"+e.toString());
                                 }
                             });
                             startActivity(new Intent(getApplicationContext(),MainActivity.class));
                         }else{
                             Toast.makeText(Register.this,"Please try again"+task.getException().getMessage(),Toast.LENGTH_LONG).show();
                         }
                     }
                 });
            }
        });
        link.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(getApplicationContext(),Login.class));
            }
        });
    }
}